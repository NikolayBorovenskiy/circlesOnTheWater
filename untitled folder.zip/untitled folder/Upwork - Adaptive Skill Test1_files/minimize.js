/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


$(document).ready(function() {
    if(document.getElementById("sfWebDebugDetails"))
        document.getElementById("sfWebDebugDetails").style.display = "none";
});